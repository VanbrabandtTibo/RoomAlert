[connector_python]
user = student
host = 127.0.0.1
port = 3306
password = W8w00rd
database = roomalert

[application_config]
driver = 'SQL Server'